from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.contrib import messages
from .models import Lutador
import re

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        senha = request.POST['password']
        user = authenticate(request, username=username, password=senha)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'login.html', {'erro': 'Usuário ou senha inválidos'})
    return render(request, 'login.html')

def registro_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        senha = request.POST['password']

        if not re.fullmatch(r'[a-zA-Z]{1,8}', username):
            messages.error(request, 'Usuário deve ter até 8 letras (apenas letras).')
            return render(request, 'registro.html')

        if not re.fullmatch(r'[a-zA-Z]{1,8}', senha):
            messages.error(request, 'Senha deve ter até 8 letras (apenas letras).')
            return render(request, 'registro.html')

        if User.objects.filter(username=username).exists():
            messages.error(request, 'Nome de usuário já existe.')
            return render(request, 'registro.html')

        User.objects.create_user(username=username, password=senha)
        return redirect('login')

    return render(request, 'registro.html')

def home(request):
    if not request.user.is_authenticated:
        return redirect('login')
    lutadores = Lutador.objects.filter(dono=request.user)
    return render(request, 'home.html', {'lutadores': lutadores})

def criar_lutador(request):
    if not request.user.is_authenticated:
        return redirect('login')
    if request.method == 'POST':
        nome = request.POST['nome']
        if Lutador.objects.filter(dono=request.user).count() >= 2:
            messages.error(request, 'Você já tem 2 lutadores.')
            return redirect('home')
        Lutador.objects.create(dono=request.user, nome=nome)
        return redirect('home')
    return render(request, 'criar_lutador.html')

def editar_lutador(request, id):
    lutador = Lutador.objects.get(id=id, dono=request.user)
    if request.method == 'POST':
        lutador.forca = int(request.POST['forca'])
        lutador.agilidade = int(request.POST['agilidade'])
        lutador.resistencia = int(request.POST['resistencia'])
        lutador.save()
        return redirect('home')
    return render(request, 'editar_lutador.html', {'lutador': lutador})
