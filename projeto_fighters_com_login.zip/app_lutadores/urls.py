from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('registro/', views.registro_view, name='registro'),
    path('criar/', views.criar_lutador, name='criar_lutador'),
    path('editar/<int:id>/', views.editar_lutador, name='editar_lutador'),
]
